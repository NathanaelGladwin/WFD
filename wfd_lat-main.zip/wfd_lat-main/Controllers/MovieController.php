<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\movies;

class MovieController extends Controller
{
    
}
